'use strict'

let slide_list = document.querySelector('.slide_list'),
  num = 0;

let imgAr = [
    './images/1.jpg',
    './images/2.jpg',
    './images/3.jpg',
    './images/4.jpg',
    './images/5.jpg',
]

for (let i = 0; i < imgAr.length; i++) {
    slide_list.innerHTML += '<li></li>';
}

let li = slide_list.querySelectorAll('li');

for (let i = 0; i < imgAr.length; i++) {
    li[i].style.background = `url(${imgAr[i]}) center/100% 100% no-repeat`;
}

let auto_slide = setInterval(() => {

    li[num % imgAr.length].style.left = '100%';
    li[num % imgAr.length].classList.remove('opacity');

    num += 1;

    li[num % imgAr.length].style.left = '0px';
    li[num % imgAr.length].classList.add('opacity');

}, 2000);