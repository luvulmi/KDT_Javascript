'use strict';

const service_container = document.querySelector('.service_container'),
    li = service_container.querySelectorAll('li'),
    Btn = document.querySelector('button');

let tar = li[0];

function textReplace(target, txt1, txt2) {
    target.children[0].textContent = target.children[0].textContent.replace(txt1, txt2);
}

function tmpRemove() {
    tar.classList.add('hidden');
    textReplace(tar, '-', '+');
}

service_container.addEventListener('click', function (e) {
    const list = e.target.parentNode;

    if (list.classList.contains('service_list')) {
        tmpRemove();

        list.classList.remove('hidden');
        textReplace(list, '+', '-');
        tar = list;
    }
});

Btn.addEventListener('click', () => {
    tmpRemove();
});